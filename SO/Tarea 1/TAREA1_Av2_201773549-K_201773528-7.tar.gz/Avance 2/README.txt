Ian Perez    201773549-K
Jose Quezada  201773528-7

***********************************************

		ATENCION


Sendo testamento incoming. Recomiendo leer c:

TL;DR avanzamos ambos puntos al mismo tiempo, pero el juego no está listo como para ejecutar. Se puede compilar y leer las funciones para comprobar nuestro progreso, pero basicamente estamos a punto de terminar. En caso de ejecutar no va a terminar nunca porque no se realizan jugadas.

************************************************


RESUMEN DE TODO:

En la entrega anterior se subió una versión del programa, en la cual al ejecutarse creaba todas las carpetas y archivos necesarios para la ejecución del programa.

En este caso, se avanzó tanto en las Pipes como en el juego en sí, pero el juego "no funciona" como tal, ya que aún no está listo completamente, pero está cerca de estarlo como para la entrega final.


DETALLES:

Consideramos que sería más complicado hacer los pipes y las jugadas en forma secuencial (hacer primero unas, y luego las otras).
Entonces, nos dividimos ambos puntos restantes, de forma que José se preocupó de hacer las jugadas, el funcionamiento del mazo, las manos, las cartas especiales y todo eso. Mientras que, por otro lado yo (Ian), hice todo lo referente a los forks y pipes, junto con la coordinación de turnos de los jugadores/envio de mensajes, yadayadayada...

Entonces, la parte de forks y pipes ya es completamente "funcional" por si sola. Es decir, puede crear los 4 procesos, crea pipes para la comunicacion de turnos, pero la parte de jugar cartas no está terminada aún, por lo que no se ha incluido dentro del programa principal.


ENTONCES:

Los mensajes se envian por pipe y se juegan los turnos en un loop "infinito" hasta que a un jugador se le acaben las cartas, pero como aún no está lista la parte de jugar cartas no va a terminar nunca c:

Como comprobar?:

1) La funcion "Jugar" contiene lo que se tiene actualmente para hacer jugadas (linea 260 aprox)

2) El uso de pipes se encuentra en 2 funciones separadas (jugadorPrincipal y jugadorPC), que se encuentran sobre el Main casi al final del programa.
3) Por ultimo, el uso de Fork y la creación de los Pipes se encuentran en el Main. (final del programa).

Asi que, basicamente recomiendo leer las funciones mencionadas en los puntos 2 y 3 (se encuentran con varios comentarios para entenderse), y NO CORRER LA TAREA (Se puede compilar), SI SE EJECUTA NO VA A TERMINAR >:(



