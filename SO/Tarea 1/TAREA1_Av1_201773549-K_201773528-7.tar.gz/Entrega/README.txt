Ian Perez    201773549-K
Jose Quezada  201773528-7

Hasta el momento se implementa la creacion de carpetas y archivos necesarios para el juego.

una vez que el juego inicie, creará una carpeta llamada "Juego" donde se contendrán todos los archivos.

"Jugadores" contiene las manos de cada jugador
"Mazo" todas las cartas que siguen en el mazo
"Last" la ultima carta jugada

Al final del juego se preguntará si se desea guardar.

En caso de responder "S", todas las carpetas se mantendrán.
De responder "N", se eliminará todo, asi que se debe señalar con "S" o no enviar nada para revisar las carpetas.
