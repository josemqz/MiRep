#include <stdio.h>
#include <stdlib.h>
#include "sorting.h"
#include <unistd.h>
#include <string.h>

// nodoInicio es el numero del nodo de inicio, y nodoFinal es el numero del nodo buscado.
// Se busca encontrar si existe un camino entre ambos nodos, que no sea el camino directo
int buscarCamino(grafo *Grafo, int nodoInicio, int nodoFinal){
        
    nodo *arr = Grafo->arrayNodos; // para simplificar el uso de indices, dejando solo el arreglo de nodos
    int maxNodo = arr[Grafo->nNodos-1].numero + 1;  // Numero del nodo m?s grande del grafo + 1
    
    
    int listaVisitados[maxNodo], listaNodos[maxNodo];
    // listaVisitados tiene tantos espacios como el numero del nodo mas grande + 1, donde los indices del arreglo correponden al numero del grafo
    // su valor es 0 o 1 segun si ha sido visitado o no
    
    //listaNodos tambien tiene tantos espacios como el nodo mas grande+1, donde el valor de cada nodo es su indice en Grafo->arregloNodos.
    memset(listaVisitados, 0, maxNodo*sizeof(int));
    memset(listaNodos, -1, maxNodo*sizeof(int));
    
    
    int index = 0;
    for(index = 0 ; index < Grafo->nNodos ; index++)
        listaNodos[arr[index].numero] = index; // cada posicion del arreglo contiene el indice del nodo con ese mismo numero, y -1 si no es parte del arreglo.
    
    int nNodos = Grafo->nNodos;
    int Cola[nNodos];
    memset(Cola, 0, nNodos*sizeof(int));
    int sizeCola = 1, pointerCola = 0;
    // La cola contiene a los nodos que se deben visitar en la proxima iteracion.
    
    Cola[0] = nodoInicio; // La cola guarda los numeros de los nodos.  
    
    
    // Funciona como un tipo de DFS. Marca nodos como visitados, agrega a la cola todos los nodos  a los que se conecta el nodo siendo revisado, y luego se revisan esos.
    while ((sizeCola - pointerCola) > 0){
        
        listaVisitados[Cola[pointerCola]] = 1; // Se marca el nodo como visitado, en caso de que no lo haya estado por alguna razon.
        int nodos = 0;
                
        for (nodos = 0 ; nodos < arr[listaNodos[Cola[pointerCola]]].n_conex ; nodos++){ // Se itera en las conexiones del nodo
            if (pointerCola == 0 && arr[listaNodos[Cola[pointerCola]]].conexiones[nodos] == nodoFinal){} // Se omite el caso base, como si la conexion no existiese.
            else if (arr[listaNodos[Cola[pointerCola]]].conexiones[nodos] == nodoFinal) return 1; // El nodo se encuentra, por lo que retorna 1
            else if (listaVisitados[arr[listaNodos[Cola[pointerCola]]].conexiones[nodos]] == 0){ // El nodo no est? visitado
                listaVisitados[arr[listaNodos[Cola[pointerCola]]].conexiones[nodos]] = 1; // Se marca el nodo como visitado.
                Cola[sizeCola] = arr[listaNodos[Cola[pointerCola]]].conexiones[nodos]; // Se agrega el nodo a la cola de visita
                sizeCola++;
            }
        }   
        pointerCola++;
    }
    return 0;
    
}

// Busqueda Binaria para el numero del nodo dentro del struct
int busquedaNodos(nodo *arrayNodos, int izq, int der, int buscado){  // Busqueda binaria pero considerando el numero de cada nodo.
    int med = izq + (der-izq)/2;
    
    if (arrayNodos[med].numero == buscado) return med;
    if (arrayNodos[med].numero > buscado) return busquedaNodos(arrayNodos, izq, med-1, buscado);
    return busquedaNodos(arrayNodos, med+1, der, buscado);
}


int busquedaBinaria(int *array, int izq, int der, int buscado){  // Funcion simple de busqueda binaria para un arreglo de ints.

    int med = izq + (der-izq)/2;
    
    if (array[med] == buscado)  return med;  //Igual al medio
    if (array[med] > buscado)   return busquedaBinaria(array, izq, med-1, buscado);  //Mayor al medio
    return busquedaBinaria(array, med+1, der, buscado); // Inferior
    
    //NO hay caso en que el elemento no existe.
}

void eliminarConexion(nodo *nodo1, nodo *nodo2){  // Se debe eliminar una conexion entre los 2 nodos recibidos
    int n1 = nodo1->numero, n2 = nodo2->numero, indexN1, indexN2;
    
    printf("%d %d\n", n1, n2);  // Se muestra la conexion que se debe eliminar, esto para satisfacer el formato del output
    
    indexN1 = busquedaBinaria(nodo1->conexiones, 0, nodo1->n_conex-1, n2);
    indexN2 = busquedaBinaria(nodo2->conexiones, 0, nodo2->n_conex-1, n1);
    // Se utiliza busqueda binaria para encontrar el indice de cada conexion que se debe eliminar
    
    for (n1 = indexN1; n1 < nodo1->n_conex-1; n1++){
        nodo1->conexiones[n1] = nodo1->conexiones[n1+1];
    } // Se mueven todos los elementos del arreglo para cubrir el espacio vacio
    for (n2 = indexN2; n2 < nodo2->n_conex-1; n2++){
        nodo2->conexiones[n2] = nodo2->conexiones[n2+1];
    }
    
    nodo1->n_conex-=1; // se disminuye la cantidad de conexiones de cada uno de los nodos
    nodo2->n_conex-=1;
    
}

// Funcion de comparacion para struct de Nodos, utilizada en Qsort
int cmpfunc(const void *nodo1, const void *nodo2){
    const nodo *n1 = (nodo *)nodo1;
    const nodo *n2 = (nodo*)nodo2; 
    
    if (n1->numero < n2->numero)  // Compara el numero de 2 nodos entregados.
        return -1;
    else if (n1->numero > n2->numero)   // Retorna si 1 es mayor, menor o igual a 2.
        return +1;
    else
        return 0;
}

void copyArray(int *destino, int *origen, int size2){ // Funcion que copia un arreglo en otro.
    int index;
    for (index = 0; index < size2; index++)
        destino[index] = origen[index];    
}

void eliminarNodo(grafo *Grafo, int index){
    int indexNodo;
    
    free(Grafo->arrayNodos[index].conexiones); // Se liberan las conexiones de un nodo
    
    for (indexNodo = index ; indexNodo < Grafo->nNodos-1 ; indexNodo++) // Se mueven todas las demas conexiones para cubrir el espacio vacio y conservar el orden
        Grafo->arrayNodos[indexNodo] = Grafo->arrayNodos[indexNodo+1];
       
    Grafo->nNodos -= 1; // Se reduce el numero de nodos en 1
}

// Elimina del grafo aquellos nodos que no tienen conexiones.
void analizarGrafo(grafo *Grafo){
    int indexNodo = 0, indexNodo2, busqueda;// base = 0;

    // Revisa cada nodo del grafo.
    while (indexNodo < Grafo->nNodos){
        if (Grafo->arrayNodos[indexNodo].n_conex == 1){ // Cuando un nodo tiene solo 1 conexion, significa que se puede cortar sin problemas
            nodo* nodo1 = &Grafo->arrayNodos[indexNodo]; // Se guarda el nodo que se debe matar
            indexNodo2 = busquedaNodos(Grafo->arrayNodos, 0, Grafo->nNodos, Grafo->arrayNodos[indexNodo].conexiones[0]);
            nodo *nodo2 = &Grafo->arrayNodos[indexNodo2]; // Se obtiene el segundo nodo a matar, buscando su numero dentro del grafo usando busqueda binaria
            
            eliminarConexion(nodo1, nodo2); // Se envia la conexion a eliminar
            Grafo->eliminaciones += 1;
            indexNodo = 0; // Se vuelve a iniciar, ya que no se sabe si la al eliminar esta conexion se libera otra.
        }
        else if (Grafo->arrayNodos[indexNodo].n_conex == 0){  // Si un nodo no tiene conexiones, no tiene motivos para existir, asi que se elimina
            eliminarNodo(Grafo, indexNodo);     // Se envia el nodo para su eliminaci?n
            indexNodo = 0;
        }
               
        else{  // Si no cumple ninguna de las condiciones anteriores se utiliza un tipo de DFS chanta, para buscar si existen mas de 2 caminos a un mismo nodo
            int flag = 0;
            for (indexNodo2 = 0 ; indexNodo2 < Grafo->arrayNodos[indexNodo].n_conex ; indexNodo2++){
                busqueda = buscarCamino(Grafo, Grafo->arrayNodos[indexNodo].numero, Grafo->arrayNodos[indexNodo].conexiones[indexNodo2]); // se ejecuta para cada conexion de un nodo.
           //     printf("busqueda: %d\n", busqueda);
                if (busqueda == 0){ // Si no se encuentra otro camino, significa que al eliminar la conexion inicial se dividira el grafo en 2.
                    nodo* nodo1 = &Grafo->arrayNodos[indexNodo];
                    nodo* nodo2 = &Grafo->arrayNodos[busquedaNodos(Grafo->arrayNodos, 0, Grafo->nNodos, Grafo->arrayNodos[indexNodo].conexiones[indexNodo2])];
                    eliminarConexion(nodo1, nodo2); // Se elimina la conexion entre ambos nodos
                    Grafo->eliminaciones += 1;
                    flag = 1;
                }
            }
            if (flag == 0) indexNodo++;
            else indexNodo = 0;
        }
    }
}



// Aplica mergeSort en los arreglos de conexiones de cada nodo, y luego aplica Qsort en la lista de nodos
void sortGrafo(grafo* Grafo){
    int indexNodo = 0;
    // Aplica mergeSort para ordenar los arreglos de conexiones de los grafos, para mantener las conexiones ordenadas por numero de menor a mayor.
    for (indexNodo = 0; indexNodo < Grafo->nNodos; indexNodo++){
        mergeSort(Grafo->arrayNodos[indexNodo].conexiones, 0, Grafo->arrayNodos[indexNodo].n_conex - 1);
    }
    // Luego, se aplica QSort para ordenar los nodos mismos dentro del grafo.
    qsort(Grafo->arrayNodos, Grafo->nNodos, sizeof(nodo), cmpfunc);
    // Se tiene el grafo ordenado por numero de nodo, y cada conexion ordenada de menor a mayor

    // Se envia el grafo a la funcion analizar, que es la que revisa qu? cortes se deben realizar.
    analizarGrafo(Grafo);
    
}


int main(){
    char dato;
    int *datos = malloc(32*sizeof(int)), limite;  // En datos se van guardando los numeros leidos del archivo.
    memset(datos, 0, 32*sizeof(int));
    int indexNodo = 0, caracteres = 0;
    
    FILE* input = stdin; // Se guarda en un archivo la entrada de stdin
    while ((dato = fgetc(input)) != EOF){
        
        memset(datos, 0, 32*sizeof(dato)); // Se inicializa el arreglo con 0.
        
        while(dato != ' ' && dato != '\n'){  // Se lee hasta un espacio o \n, es decir, se lee un numero del archivo, correspondiente al n� de nodos.
            datos[caracteres] = (int)dato -48;
            caracteres++;
            dato = fgetc(input); // Cuando termina lee el \n  // Se van guardando en el arreglo de datos, y se lleva cuenta de cuantos digitos hay.
        }
        
        limite = 0;
        int i;
        for (i = 0; i < caracteres; i++)    // Se compone el numero, digito por digito. Corresponde al n� de nodos.
            limite = 10 * limite + datos[i];
        
        grafo* Grafo = malloc(sizeof(grafo));
        memset(Grafo, 0, sizeof(grafo));
        
        Grafo->arrayNodos = malloc(limite*sizeof(nodo));
        memset(Grafo->arrayNodos, 0, limite*sizeof(nodo));
        
        Grafo->nNodos = limite;
        Grafo->eliminaciones = 0;
        
        for (indexNodo = 0 ; indexNodo < limite ; indexNodo++){
            Grafo->arrayNodos[indexNodo].conexiones = malloc(limite*sizeof(int));
            memset(Grafo->arrayNodos[indexNodo].conexiones, 0, limite*sizeof(int));
            Grafo->arrayNodos[indexNodo].n_conex = 0;
        }
        
        // Se crea el grafo con todos los nodos correspondientes, y memoria inicializada en 0 para todo.
    
        indexNodo = 0;
        
        char buff[2048];
        memset(buff, 0, 2048*sizeof(char)); // Se tiene un buffer de 2048 para leer. Esto se refiere a 2048 caracteres en una misma linea.
        
        int size = 0;
        while (indexNodo < limite){
            dato = fgetc(input);
            //printf("%c", dato);
            
            if (dato == '\n'){ // Se lee hasta el termino de linea.
                int numero = 0, indexArray = 0, indice = 0, verify = 1;
                
                for (indice = 0; indice <= size ; indice++){
                    
                    if (buff[indice] == ' ' || indice == size){  // Se agregan digitos al arreglo hasta que se encuentra un espacio o salto de linea
                                                                 // En este punto, se componen los digitos en el numero y se asigna a su espacio correspondiente.
                        if (verify == 1){       // Verify lleva cuenta de si el numero leido corresponde al numero del nodo o a una conexion de este.
                            Grafo->arrayNodos[indexNodo].numero = numero;
                            verify = 0;
                        }
                        else{
                            Grafo->arrayNodos[indexNodo].conexiones[indexArray] = numero;
                            Grafo->arrayNodos[indexNodo].n_conex++;
                            indexArray++;
                            
                        }
                        numero = 0;
                    }
                    
                    else  numero = 10*numero + (int)buff[indice]-48; // Composicion del numero 
                }
                //printf("\n");
                
                indexNodo++;
                size = 0;
                memset(buff, 0, 2048*sizeof(char));  // Se reinicia el arreglo para la nueva linea
            }
            else{
                //printf("%c", dato);
                buff[size] = dato;
                size++;
            }
        }
       
        sortGrafo(Grafo);
        // Se envia el grafo a las dem?s funciones
        
        if (Grafo->eliminaciones == 0)
            puts("No Existe Corte.");
        // Se libera la memoria, y se muestra si no se realizo ningun corte.
        for (indexNodo = 0 ; indexNodo < Grafo->nNodos ; indexNodo++){
            free(Grafo->arrayNodos[indexNodo].conexiones);
        }
        free(Grafo->arrayNodos);
        free(Grafo);
        puts("\n");
    } 
    free(datos);
    return 0;
}