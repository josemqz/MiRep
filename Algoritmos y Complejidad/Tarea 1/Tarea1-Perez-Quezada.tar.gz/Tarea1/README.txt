Para ejecutar el programa solo se debe utilizar el make, y luego correr la tarea con ./main < (nombre archivo).

Se requiere que estén los archivos

main.c
sorting.c
sorting.h
el archivo de input que se vaya a utilizar.
