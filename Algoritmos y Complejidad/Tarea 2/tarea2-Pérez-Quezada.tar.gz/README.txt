
Problema 1

Para ejecutar el programa se debe usar el comando "make" para compilar.

Luego de esto, se debe ejecutar utilizando el comando
"./main < [archivo de input]"

Los resultados se imprimiran por pantalla en orden, de la forma:

-Multiplicacion rapida
-Multiplicacion normal

ademas se crea un archivo extra llamado "resultados.txt", que contiene
para cada número, el tiempo que tomó en resolver cada ejercicio.


Problema 2

    Se debe contar con un archivo de texto que contenga los datos especificados en la pauta
    Escribir por consola "gcc 2.c -Wall -o d && ./d <archivo de texto>"

