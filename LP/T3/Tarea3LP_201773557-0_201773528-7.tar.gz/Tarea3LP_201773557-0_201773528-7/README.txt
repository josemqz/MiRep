Integrantes:
    -Martín Salinas Scussolin
        Rol: 201773557-0
    -José Quezada Silva
        Rol: 201773528-7

Instrucciones:
    - Estando ubicado en carpeta "Tarea3_LP_201773557-0_201773528-7", abrir terminal y ejecutar "make"
    - Ejecutar "java -jar Juego.jar"
    - Jugar!

Notaciones:
    - "CHOSEN LUCKY NUMBER" no quiere decir que se utilice la habilidad suerte.
    - Solo utilizar números al seleccionar la accion en peleas.

Recomendaciones:
    - Jugar con terminal en pantalla completa.
    - Intentar errores de input previo a peleas. (lol)

Hacks:
    - 98367828 en cualquier batalla al elegir acción.
